﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyProJect.Object
{
    public class TypeInfo
    {
        private int id;
        private string typeName;

        public int Id { get => id; set => id = value; }
        public string TypeName { get => typeName; set => typeName = value; }
    }
}
