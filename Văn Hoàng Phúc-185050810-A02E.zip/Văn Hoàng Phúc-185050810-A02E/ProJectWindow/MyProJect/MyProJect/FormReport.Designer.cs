﻿namespace MyProJect
{
    partial class FormReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblMostPro = new System.Windows.Forms.Label();
            this.lblAmount = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblLeastPro = new System.Windows.Forms.Label();
            this.lblMostProAmount = new System.Windows.Forms.Label();
            this.lblLeastProAmount = new System.Windows.Forms.Label();
            this.lblTotalPrice = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbFilter = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.gr_Statis = new System.Windows.Forms.GroupBox();
            this.gr_Statis.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(151, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "REPORT";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(38, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Saling Amount:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(51, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Total money:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(5, 102);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(121, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Hot Selling Product:";
            // 
            // lblMostPro
            // 
            this.lblMostPro.AutoSize = true;
            this.lblMostPro.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMostPro.Location = new System.Drawing.Point(135, 94);
            this.lblMostPro.Name = "lblMostPro";
            this.lblMostPro.Padding = new System.Windows.Forms.Padding(3);
            this.lblMostPro.Size = new System.Drawing.Size(43, 21);
            this.lblMostPro.TabIndex = 5;
            this.lblMostPro.Text = "label6";
            // 
            // lblAmount
            // 
            this.lblAmount.AutoSize = true;
            this.lblAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAmount.Location = new System.Drawing.Point(135, 16);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Padding = new System.Windows.Forms.Padding(3);
            this.lblAmount.Size = new System.Drawing.Size(43, 21);
            this.lblAmount.TabIndex = 4;
            this.lblAmount.Text = "label7";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(219, 102);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 13);
            this.label8.TabIndex = 9;
            this.label8.Text = "Amount:";
            // 
            // lblLeastPro
            // 
            this.lblLeastPro.AutoSize = true;
            this.lblLeastPro.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLeastPro.Location = new System.Drawing.Point(135, 130);
            this.lblLeastPro.Name = "lblLeastPro";
            this.lblLeastPro.Padding = new System.Windows.Forms.Padding(3);
            this.lblLeastPro.Size = new System.Drawing.Size(43, 21);
            this.lblLeastPro.TabIndex = 8;
            this.lblLeastPro.Text = "label9";
            // 
            // lblMostProAmount
            // 
            this.lblMostProAmount.AutoSize = true;
            this.lblMostProAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMostProAmount.Location = new System.Drawing.Point(317, 94);
            this.lblMostProAmount.Name = "lblMostProAmount";
            this.lblMostProAmount.Padding = new System.Windows.Forms.Padding(3);
            this.lblMostProAmount.Size = new System.Drawing.Size(49, 21);
            this.lblMostProAmount.TabIndex = 12;
            this.lblMostProAmount.Text = "label11";
            // 
            // lblLeastProAmount
            // 
            this.lblLeastProAmount.AutoSize = true;
            this.lblLeastProAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLeastProAmount.Location = new System.Drawing.Point(317, 130);
            this.lblLeastProAmount.Name = "lblLeastProAmount";
            this.lblLeastProAmount.Padding = new System.Windows.Forms.Padding(3);
            this.lblLeastProAmount.Size = new System.Drawing.Size(49, 21);
            this.lblLeastProAmount.TabIndex = 11;
            this.lblLeastProAmount.Text = "label12";
            // 
            // lblTotalPrice
            // 
            this.lblTotalPrice.AutoSize = true;
            this.lblTotalPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTotalPrice.Location = new System.Drawing.Point(135, 54);
            this.lblTotalPrice.Name = "lblTotalPrice";
            this.lblTotalPrice.Padding = new System.Windows.Forms.Padding(3);
            this.lblTotalPrice.Size = new System.Drawing.Size(49, 21);
            this.lblTotalPrice.TabIndex = 10;
            this.lblTotalPrice.Text = "label13";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(219, 138);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 13);
            this.label10.TabIndex = 13;
            this.label10.Text = "Amount:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(5, 138);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Not selling well:";
            // 
            // cmbFilter
            // 
            this.cmbFilter.FormattingEnabled = true;
            this.cmbFilter.Items.AddRange(new object[] {
            "All",
            "Today",
            "This Month",
            "This Year"});
            this.cmbFilter.Location = new System.Drawing.Point(237, 54);
            this.cmbFilter.Name = "cmbFilter";
            this.cmbFilter.Size = new System.Drawing.Size(121, 21);
            this.cmbFilter.TabIndex = 15;
            this.cmbFilter.SelectedIndexChanged += new System.EventHandler(this.cmbFilter_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(364, 57);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "Filter";
            // 
            // gr_Statis
            // 
            this.gr_Statis.Controls.Add(this.lblAmount);
            this.gr_Statis.Controls.Add(this.label2);
            this.gr_Statis.Controls.Add(this.label3);
            this.gr_Statis.Controls.Add(this.label5);
            this.gr_Statis.Controls.Add(this.label4);
            this.gr_Statis.Controls.Add(this.label10);
            this.gr_Statis.Controls.Add(this.lblMostPro);
            this.gr_Statis.Controls.Add(this.lblMostProAmount);
            this.gr_Statis.Controls.Add(this.lblLeastPro);
            this.gr_Statis.Controls.Add(this.lblLeastProAmount);
            this.gr_Statis.Controls.Add(this.label8);
            this.gr_Statis.Controls.Add(this.lblTotalPrice);
            this.gr_Statis.Location = new System.Drawing.Point(2, 81);
            this.gr_Statis.Name = "gr_Statis";
            this.gr_Statis.Size = new System.Drawing.Size(400, 171);
            this.gr_Statis.TabIndex = 17;
            this.gr_Statis.TabStop = false;
            this.gr_Statis.Text = "Statistics";
            // 
            // FormReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(409, 259);
            this.Controls.Add(this.gr_Statis);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cmbFilter);
            this.Controls.Add(this.label1);
            this.Name = "FormReport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormReport";
            this.Load += new System.EventHandler(this.FormReport_Load);
            this.gr_Statis.ResumeLayout(false);
            this.gr_Statis.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblMostPro;
        private System.Windows.Forms.Label lblAmount;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblLeastPro;
        private System.Windows.Forms.Label lblMostProAmount;
        private System.Windows.Forms.Label lblLeastProAmount;
        private System.Windows.Forms.Label lblTotalPrice;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbFilter;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox gr_Statis;
    }
}